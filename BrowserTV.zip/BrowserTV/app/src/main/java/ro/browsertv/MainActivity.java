package ro.browsertv;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends Activity {
    static final int BG = 0xFF0A1A33, BAR = 0xFF0D47A1, BLUE = 0xFF1565C0, LIGHT = 0xFF42A5F5;
    static final String DESKTOP_UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
    static final String[][] SITES = {
        {"YouTube", "https://www.youtube.com"}, {"Netflix", "https://www.netflix.com"},
        {"Spotify", "https://open.spotify.com"}, {"Plex", "https://app.plex.tv"},
        {"Facebook", "https://m.facebook.com"}, {"Google", "https://www.google.com"},
        {"Disney+", "https://www.disneyplus.com"}, {"Prime Video", "https://www.primevideo.com"},
        {"Twitch", "https://www.twitch.tv"}, {"HBO Max", "https://www.max.com"},
        {"Instagram", "https://www.instagram.com"}, {"TikTok", "https://www.tiktok.com"}
    };

    FrameLayout root, content;
    LinearLayout bar, homeBox;
    ScrollView home;
    WebView web;
    CursorView cursor;
    View progress, customView, firstBtn;
    TextView firstTile;
    EditText url;
    WebChromeClient chrome;
    WebChromeClient.CustomViewCallback customCb;
    SharedPreferences prefs;
    String defaultUa;
    boolean webMode = false, cursorMode = true, desktop = true, clearHist = false;
    float cx, cy;

    int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }
    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        prefs = getSharedPreferences("fav", MODE_PRIVATE);
        cx = dp(400); cy = dp(200);
        root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        buildBar();
        col.addView(bar);
        progress = new View(this);
        progress.setBackgroundColor(LIGHT);
        col.addView(progress, new LinearLayout.LayoutParams(0, dp(3)));
        content = new FrameLayout(this);
        col.addView(content, new LinearLayout.LayoutParams(-1, 0, 1f));
        root.addView(col, new FrameLayout.LayoutParams(-1, -1));
        buildWeb();
        home = new ScrollView(this);
        homeBox = new LinearLayout(this);
        homeBox.setOrientation(LinearLayout.VERTICAL);
        homeBox.setPadding(dp(24), dp(16), dp(24), dp(16));
        home.addView(homeBox);
        cursor = new CursorView(this);
        content.addView(home, new FrameLayout.LayoutParams(-1, -1));
        content.addView(web, new FrameLayout.LayoutParams(-1, -1));
        content.addView(cursor, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        showHome();
    }

    // ---------- UI ----------
    GradientDrawable shape(int fill, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(10));
        if (stroke != 0) g.setStroke(dp(3), stroke);
        return g;
    }

    Drawable selector(int color) {
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_focused}, shape(LIGHT, Color.WHITE));
        s.addState(new int[]{android.R.attr.state_pressed}, shape(LIGHT, Color.WHITE));
        s.addState(new int[]{}, shape(color, 0));
        return s;
    }

    TextView btn(String label, final Runnable r) {
        TextView v = new TextView(this);
        v.setText(label);
        v.setTextColor(Color.WHITE);
        v.setTextSize(14);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(10), dp(8), dp(10), dp(8));
        v.setFocusable(true);
        v.setClickable(true);
        v.setBackground(selector(BLUE));
        v.setOnClickListener(x -> r.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.setMargins(dp(3), 0, dp(3), 0);
        v.setLayoutParams(lp);
        return v;
    }

    void buildBar() {
        bar = new LinearLayout(this);
        bar.setBackgroundColor(BAR);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(8), dp(6), dp(8), dp(6));
        firstBtn = btn("Înapoi", () -> { if (webMode && web.canGoBack()) web.goBack(); else showHome(); });
        bar.addView(firstBtn);
        bar.addView(btn("Înainte", () -> { if (webMode && web.canGoForward()) web.goForward(); }));
        bar.addView(btn("Reîncarcă", () -> { if (webMode) web.reload(); }));
        bar.addView(btn("Acasă", () -> showHome()));
        url = new EditText(this);
        url.setSingleLine(true);
        url.setHint("Caută sau introdu adresa");
        url.setHintTextColor(0xAAFFFFFF);
        url.setTextColor(Color.WHITE);
        url.setTextSize(15);
        url.setPadding(dp(14), dp(6), dp(14), dp(6));
        url.setBackground(selector(0xFF0A2A5E));
        url.setImeOptions(EditorInfo.IME_ACTION_GO);
        url.setOnEditorActionListener((v, id, ev) -> { go(url.getText().toString()); return true; });
        LinearLayout.LayoutParams ulp = new LinearLayout.LayoutParams(0, -2, 1f);
        ulp.setMargins(dp(6), 0, dp(6), 0);
        bar.addView(url, ulp);
        bar.addView(btn("★", () -> addFav()));
        bar.addView(btn("Cast", () -> cast()));
        bar.addView(btn("Meniu", () -> showMenu()));
    }

    void buildWeb() {
        web = new WebView(this);
        web.setBackgroundColor(Color.WHITE);
        WebSettings s = web.getSettings();
        defaultUa = s.getUserAgentString();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setUserAgentString(DESKTOP_UA);
        CookieManager.getInstance().setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= 21) {
            s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
            CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);
        }
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, String u) {
                if (u.startsWith("http")) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u))); } catch (Exception e) { }
                return true;
            }
            @Override public void onPageStarted(WebView v, String u, Bitmap f) {
                if (!"about:blank".equals(u)) url.setText(u);
            }
            @Override public void onPageFinished(WebView v, String u) {
                if (clearHist && "about:blank".equals(u)) { web.clearHistory(); clearHist = false; }
            }
        });
        chrome = new WebChromeClient() {
            @Override public void onProgressChanged(WebView v, int p) {
                ViewGroup.LayoutParams lp = progress.getLayoutParams();
                lp.width = p >= 100 ? 0 : root.getWidth() * p / 100;
                progress.setLayoutParams(lp);
            }
            @Override public void onShowCustomView(View view, CustomViewCallback cb) {
                if (customView != null) { cb.onCustomViewHidden(); return; }
                customView = view; customCb = cb;
                view.setBackgroundColor(Color.BLACK);
                root.addView(view, new FrameLayout.LayoutParams(-1, -1));
            }
            @Override public void onHideCustomView() {
                if (customView == null) return;
                root.removeView(customView);
                customView = null;
                customCb.onCustomViewHidden();
            }
            @Override public Bitmap getDefaultVideoPoster() {
                return Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
            }
        };
        web.setWebChromeClient(chrome);
    }

    // ---------- Home ----------
    TextView tile(final String[] a) {
        final boolean fav = a[2].equals("1");
        TextView v = new TextView(this);
        v.setText(a[0]);
        v.setTextColor(Color.WHITE);
        v.setTextSize(22);
        v.setTypeface(null, Typeface.BOLD);
        v.setGravity(Gravity.CENTER);
        v.setFocusable(true);
        v.setClickable(true);
        v.setBackground(selector(fav ? 0xFF0B3D91 : BLUE));
        v.setOnClickListener(x -> go(a[1]));
        if (fav) v.setOnLongClickListener(x -> { removeFav(a); return true; });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(100), 1f);
        lp.setMargins(dp(8), dp(8), dp(8), dp(8));
        v.setLayoutParams(lp);
        return v;
    }

    void refreshHome() {
        homeBox.removeAllViews();
        TextView t = new TextView(this);
        t.setText("Browser TV");
        t.setTextColor(Color.WHITE);
        t.setTextSize(34);
        t.setTypeface(null, Typeface.BOLD);
        homeBox.addView(t);
        TextView s = new TextView(this);
        s.setText("Alege o aplicație sau caută pe web. Ține apăsat pe o pagină salvată (★) ca să o ștergi.");
        s.setTextColor(LIGHT);
        s.setTextSize(15);
        s.setPadding(0, 0, 0, dp(12));
        homeBox.addView(s);
        List<String[]> all = new ArrayList<String[]>();
        for (String[] x : SITES) all.add(new String[]{x[0], x[1], "0"});
        for (String f : new ArrayList<String>(prefs.getStringSet("f", new HashSet<String>()))) {
            String[] p = f.split("\\|", 2);
            if (p.length == 2) all.add(new String[]{p[0], p[1], "1"});
        }
        firstTile = null;
        for (int i = 0; i < all.size(); i += 4) {
            LinearLayout row = new LinearLayout(this);
            for (int j = i; j < i + 4; j++) {
                if (j < all.size()) {
                    TextView tv = tile(all.get(j));
                    row.addView(tv);
                    if (firstTile == null) firstTile = tv;
                } else {
                    row.addView(new View(this), new LinearLayout.LayoutParams(0, dp(10), 1f));
                }
            }
            homeBox.addView(row);
        }
    }

    void addFav() {
        if (!webMode || web.getUrl() == null) { toast("Deschide mai întâi o pagină"); return; }
        String u = web.getUrl(), t = web.getTitle();
        if (t == null || t.length() == 0) t = u;
        t = t.replace("|", "-");
        if (t.length() > 24) t = t.substring(0, 24);
        Set<String> s = new HashSet<String>(prefs.getStringSet("f", new HashSet<String>()));
        s.add(t + "|" + u);
        prefs.edit().putStringSet("f", s).apply();
        refreshHome();
        toast("Adăugat pe pagina de start");
    }

    void removeFav(String[] a) {
        Set<String> s = new HashSet<String>(prefs.getStringSet("f", new HashSet<String>()));
        s.remove(a[0] + "|" + a[1]);
        prefs.edit().putStringSet("f", s).apply();
        refreshHome();
        if (firstTile != null) firstTile.requestFocus();
        toast("Șters");
    }

    void showHome() {
        webMode = false;
        clearHist = true;
        web.loadUrl("about:blank");
        web.setVisibility(View.GONE);
        cursor.setVisibility(View.INVISIBLE);
        home.setVisibility(View.VISIBLE);
        url.setText("");
        refreshHome();
        home.post(() -> { if (firstTile != null) firstTile.requestFocus(); });
    }

    void showWeb() {
        webMode = true;
        cursorMode = true;
        home.setVisibility(View.GONE);
        web.setVisibility(View.VISIBLE);
        cursor.setVisibility(View.VISIBLE);
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(url.getWindowToken(), 0);
        web.requestFocus();
        cursor.invalidate();
    }

    void go(String in) {
        in = in.trim();
        if (in.length() == 0) return;
        String u;
        if (in.startsWith("http://") || in.startsWith("https://")) u = in;
        else if (in.contains(".") && !in.contains(" ")) u = "https://" + in;
        else u = "https://www.google.com/search?q=" + Uri.encode(in);
        clearHist = false;
        showWeb();
        web.loadUrl(u);
    }

    // ---------- Meniu, Cast ----------
    void showMenu() {
        final String[] items = {"Zoom +", "Zoom −",
            "Cursor: " + (cursorMode ? "oprește" : "pornește"),
            "Mod: " + (desktop ? "treci la mobil" : "treci la desktop"),
            "Șterge istoric și cookie-uri", "Ieșire"};
        new AlertDialog.Builder(this).setTitle("Meniu").setItems(items, (d, w) -> {
            switch (w) {
                case 0: web.zoomIn(); break;
                case 1: web.zoomOut(); break;
                case 2:
                    if (webMode) {
                        cursorMode = !cursorMode;
                        cursor.setVisibility(cursorMode ? View.VISIBLE : View.INVISIBLE);
                        if (cursorMode) web.requestFocus();
                    }
                    break;
                case 3:
                    desktop = !desktop;
                    web.getSettings().setUserAgentString(desktop ? DESKTOP_UA : defaultUa);
                    if (webMode) web.reload();
                    break;
                case 4:
                    web.clearCache(true);
                    web.clearHistory();
                    CookieManager.getInstance().removeAllCookie();
                    toast("Date șterse");
                    break;
                case 5: finish(); break;
            }
        }).show();
    }

    void cast() {
        try {
            startActivity(new Intent("android.settings.CAST_SETTINGS"));
        } catch (Exception e) {
            try {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, webMode && web.getUrl() != null ? web.getUrl() : "");
                startActivity(Intent.createChooser(i, "Trimite linkul"));
            } catch (Exception e2) {
                toast("Cast indisponibil pe acest televizor");
            }
        }
    }

    // ---------- Cursor albastru ----------
    class CursorView extends View {
        Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG), line = new Paint(Paint.ANTI_ALIAS_FLAG);
        Path p = new Path();
        CursorView(Context c) {
            super(c);
            fill.setColor(0xFF2196F3);
            line.setColor(Color.WHITE);
            line.setStyle(Paint.Style.STROKE);
            line.setStrokeWidth(dp(2));
            float s = dp(1.3f);
            p.moveTo(0, 0); p.lineTo(0, 24 * s); p.lineTo(6 * s, 18 * s); p.lineTo(11 * s, 29 * s);
            p.lineTo(15 * s, 27 * s); p.lineTo(10 * s, 16 * s); p.lineTo(18 * s, 16 * s); p.close();
        }
        @Override protected void onDraw(Canvas c) {
            c.save();
            c.translate(cx, cy);
            c.drawPath(p, fill);
            c.drawPath(p, line);
            c.restore();
        }
    }

    void moveCursor(int k, int rep) {
        int step = (int) (dp(8) + Math.min(rep, 30) * dp(1) * 0.8f);
        int w = content.getWidth(), h = content.getHeight(), edge = dp(30);
        switch (k) {
            case KeyEvent.KEYCODE_DPAD_LEFT:
                if (cx <= 0) web.scrollBy(-step * 2, 0);
                cx = Math.max(0, cx - step); break;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                if (cx >= w - 1) web.scrollBy(step * 2, 0);
                cx = Math.min(w - 1, cx + step); break;
            case KeyEvent.KEYCODE_DPAD_UP:
                if (cy <= 0 && web.getScrollY() <= 0) { goBar(); return; }
                if (cy < edge) web.scrollBy(0, -step * 2);
                cy = Math.max(0, cy - step); break;
            case KeyEvent.KEYCODE_DPAD_DOWN:
                if (cy > h - edge) web.scrollBy(0, step * 2);
                cy = Math.min(h - 1, cy + step); break;
        }
        cursor.invalidate();
    }

    void goBar() {
        cursorMode = false;
        cursor.setVisibility(View.INVISIBLE);
        firstBtn.requestFocus();
    }

    void tap() {
        final long t = SystemClock.uptimeMillis();
        final float x = cx, y = cy;
        MotionEvent d = MotionEvent.obtain(t, t, MotionEvent.ACTION_DOWN, x, y, 0);
        web.dispatchTouchEvent(d);
        d.recycle();
        web.postDelayed(() -> {
            MotionEvent u = MotionEvent.obtain(t, SystemClock.uptimeMillis(), MotionEvent.ACTION_UP, x, y, 0);
            web.dispatchTouchEvent(u);
            u.recycle();
        }, 60);
        web.postDelayed(() -> {
            if (web.getHitTestResult().getType() == WebView.HitTestResult.EDIT_TEXT_TYPE) {
                cursorMode = false;
                cursor.setVisibility(View.INVISIBLE);
                web.requestFocus();
            }
        }, 350);
    }

    boolean inBar(View v) { return v != null && v.getParent() == bar; }

    @Override public boolean dispatchKeyEvent(KeyEvent e) {
        if (customView == null) {
            int k = e.getKeyCode();
            boolean down = e.getAction() == KeyEvent.ACTION_DOWN;
            if (k == KeyEvent.KEYCODE_MENU) {
                if (down && e.getRepeatCount() == 0) showMenu();
                return true;
            }
            if (webMode) {
                if (cursorMode) {
                    switch (k) {
                        case KeyEvent.KEYCODE_DPAD_LEFT:
                        case KeyEvent.KEYCODE_DPAD_RIGHT:
                        case KeyEvent.KEYCODE_DPAD_UP:
                        case KeyEvent.KEYCODE_DPAD_DOWN:
                            if (down) moveCursor(k, e.getRepeatCount());
                            return true;
                        case KeyEvent.KEYCODE_DPAD_CENTER:
                        case KeyEvent.KEYCODE_ENTER:
                            if (down && e.getRepeatCount() == 0) tap();
                            return true;
                    }
                } else if (k == KeyEvent.KEYCODE_DPAD_DOWN && down && inBar(getCurrentFocus())) {
                    cursorMode = true;
                    cursor.setVisibility(View.VISIBLE);
                    web.requestFocus();
                    return true;
                }
            }
        }
        return super.dispatchKeyEvent(e);
    }

    @Override public void onBackPressed() {
        if (customView != null) { chrome.onHideCustomView(); return; }
        if (webMode) {
            if (!cursorMode) {
                cursorMode = true;
                cursor.setVisibility(View.VISIBLE);
                web.requestFocus();
                return;
            }
            if (web.canGoBack()) web.goBack(); else showHome();
            return;
        }
        super.onBackPressed();
    }

    @Override protected void onDestroy() {
        web.destroy();
        super.onDestroy();
    }
}
