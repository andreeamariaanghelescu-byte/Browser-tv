BROWSER TV - proiect Android (Java, fără dependențe externe, minSdk 19)

VARIANTA 1 - Android Studio (PC)
1. Dezarhivează, apoi File > Open > alege folderul BrowserTV.
2. Așteaptă sincronizarea Gradle (descarcă SDK-ul necesar, dacă îți cere).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK-ul: app/build/outputs/apk/debug/app-debug.apk

VARIANTA 2 - GitHub (fără Android Studio)
1. Creează un depozit gratuit pe github.com și încarcă tot conținutul acestui folder (inclusiv .github).
2. Tab Actions > Build APK > Run workflow.
3. După câteva minute descarci APK-ul din Artifacts (BrowserTV-apk).

INSTALARE PE TV
Copiază app-debug.apk pe un stick USB (sau trimite-l cu "Send Files to TV"), deschide-l din managerul de fișiere al televizorului și permite instalarea din surse necunoscute.

TELECOMANDĂ
- Săgeți: mută cursorul albastru; la marginea de jos/sus pagina derulează
- OK: click | Săgeată sus la marginea de sus: mergi la bara de butoane
- Săgeată jos din bară: revii la cursor
- Meniu (tasta Menu sau butonul Meniu): zoom, cursor, mod desktop/mobil, ștergere date
- Înapoi: pagina anterioară, apoi pagina de start
- Când scrii într-un câmp text, cursorul se oprește automat; apasă Înapoi ca să-l pornești din nou
